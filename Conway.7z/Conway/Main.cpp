#include "SDL.h"

#ifdef _DEBUG
#include <crtdbg.h>
#define _CRTDBG_MAP_ALLOC
#endif

#include "Application.h"

int main(int argc, char* argv[])
{
	Application* myApp = new Application(960, 640);

	myApp->run();

	delete myApp;

	return 0;
}