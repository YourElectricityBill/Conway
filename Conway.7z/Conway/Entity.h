#pragma once

#include "SDL.h"

struct Entity
{
	SDL_Texture* m_entityTexture;
	SDL_Rect m_destRect;
};