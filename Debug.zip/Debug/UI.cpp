#include "UI.h"
#include "Application.h"
#include "Game.h"

SDL_Texture* Button::m_buttonTexture;
TTF_Font* Button::m_buttonFont;
std::vector <Button*> Application::m_buttonVector;

Button::Button()
{
	static int number = 0;
	if (number == 0)
	{
		m_buttonType = Enter;
		m_buttonText = "Enter";
	}
	else if (number == 1)
	{
		m_buttonType = About;
		m_buttonText = "About";
	}
	else
	{
		m_buttonType = Exit;
		m_buttonText = "Exit";
	}

	SDL_Surface* fontSurface = TTF_RenderText_Solid(m_buttonFont, m_buttonText.c_str(), { 255, 255, 255, 255 });
	//Application::checkForError(fontSurface);
	m_buttonInscription = SDL_CreateTextureFromSurface(Application::m_appRenderer, fontSurface);
	SDL_FreeSurface(fontSurface);

	int inscriptionWidth = 0;
	int inscriptionHeight = 0;

	SDL_QueryTexture(m_buttonInscription, NULL, NULL, &inscriptionWidth, &inscriptionHeight);

	m_inscriptionDimension.w = inscriptionWidth * 1.25f;
	m_inscriptionDimension.h = inscriptionHeight * 1.25f;
	m_inscriptionDimension.x = ((Application::m_windowWidth / 2) - (m_inscriptionDimension.w / 2));
	m_inscriptionDimension.y = ((Application::m_windowHeight * 0.35f) + (140 * number));

	m_buttonBackgroundDimension.w = inscriptionWidth * 2.25f;
	m_buttonBackgroundDimension.h = inscriptionHeight * 2.25f;
	m_buttonBackgroundDimension.x = ((Application::m_windowWidth / 2) - (m_buttonBackgroundDimension.w / 2));
	m_buttonBackgroundDimension.y = m_inscriptionDimension.y - m_inscriptionDimension.h * 0.6f;

	++number;
}

void Button::setUpButtons()
{
	Button::m_buttonTexture = Application::loadTexture("Button Background.png");
	Button::m_buttonFont = TTF_OpenFont("arial.ttf", 18);

	for (int number = 0; number < Application::m_numberOfButtons; ++number)
	{
		Application::m_buttonVector.emplace_back(new Button());
	}
}

void Button::doAction()
{
	if (m_buttonType == Enter)
	{
		Game::m_isPaused = false;
	}
	else if (m_buttonType == About)
	{

	}
	else if (m_buttonType == Exit)
	{
		Application::m_isRunning = false;
	}
	else
	{
		SDL_Log("UNKNOWN BUTTON TYPE");
		exit(1);
	}
}

void Button::drawButton()
{
	for (Button* currentButton : Application::m_buttonVector)
	{
		SDL_RenderCopy(Application::m_appRenderer, Button::m_buttonTexture, NULL, &currentButton->m_buttonBackgroundDimension);
		SDL_RenderCopy(Application::m_appRenderer, currentButton->m_buttonInscription, NULL, &currentButton->m_inscriptionDimension);
	}
}